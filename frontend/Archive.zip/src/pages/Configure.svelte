<script>
  import { credentials } from '../stores.js';

  let creds = JSON.parse($credentials)
</script>

<h2>Configure</h2>

<p>stuff</p>