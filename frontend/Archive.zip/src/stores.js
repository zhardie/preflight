import { writable, readable } from 'svelte/store';

// Config
export const apiHost = readable('https://8080-dot-3050988-dot-devshell.appspot.com');
export const apiHeaders = readable({
    'Content-Type': 'application/json',
    'cookie': 'devshell-proxy-session=d01c1780cd4b214eb7d28a75478e0d696f43b83249955a7b049cc68560b65dd7'
});
// End Config

export const credentials = writable(false);